package com.lts.foodwiring;

import java.util.List;

public interface Menu {
List<String> itemsAvailable();
}
